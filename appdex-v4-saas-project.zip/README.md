
# AppDix v4 – SaaS Attendance System

Production-ready scaffold for an attendance + payroll system.

Stack
- React (Vite)
- Node.js + Express API
- PostgreSQL
- JWT Authentication
- Android WebView wrapper

Core Features
- Employee login
- Admin dashboard
- Attendance check-in/out
- Leave requests + approval
- Salary calculation
- REST API
