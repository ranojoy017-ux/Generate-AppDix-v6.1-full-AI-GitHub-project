
function calculateSalary(hours,rate){

let normal = 0
let overtime = 0

if(hours >= 10){
 normal = 10 * rate
 overtime = (hours-10) * rate * 1.5
}

if(hours < 10 && hours >= 5){
 normal = 5 * rate
}

return {
 normal,
 overtime,
 total: normal + overtime
}

}

module.exports = calculateSalary
