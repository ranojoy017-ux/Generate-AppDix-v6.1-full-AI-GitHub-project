
CREATE TABLE employees(
id SERIAL PRIMARY KEY,
employee_id VARCHAR UNIQUE,
name TEXT,
password TEXT,
role TEXT,
hourly_rate NUMERIC
);

CREATE TABLE attendance(
id SERIAL PRIMARY KEY,
employee_id VARCHAR,
check_in TIMESTAMP,
check_out TIMESTAMP
);

CREATE TABLE leave_requests(
id SERIAL PRIMARY KEY,
employee_id VARCHAR,
leave_date DATE,
status TEXT
);
