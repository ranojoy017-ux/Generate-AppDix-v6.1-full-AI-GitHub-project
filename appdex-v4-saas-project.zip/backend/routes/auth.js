
const router = require("express").Router()
const db = require("../db")
const jwt = require("jsonwebtoken")
const bcrypt = require("bcrypt")

router.post("/login",async(req,res)=>{

const {employee_id,password} = req.body

const result = await db.query(
"SELECT * FROM employees WHERE employee_id=$1",
[employee_id]
)

if(result.rows.length===0){
 return res.status(401).json({error:"User not found"})
}

const user = result.rows[0]

const valid = await bcrypt.compare(password,user.password)

if(!valid){
 return res.status(401).json({error:"Wrong password"})
}

const token = jwt.sign(
 {id:user.employee_id,role:user.role},
 "appdex_secret"
)

res.json({token,user})

})

module.exports = router
