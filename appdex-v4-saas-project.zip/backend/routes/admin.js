
const router = require("express").Router()
const db = require("../db")

router.get("/employees",async(req,res)=>{

const result = await db.query("SELECT * FROM employees")

res.json(result.rows)

})

module.exports = router
