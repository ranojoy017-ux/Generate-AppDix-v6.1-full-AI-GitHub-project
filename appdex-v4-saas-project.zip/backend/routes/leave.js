
const router = require("express").Router()
const db = require("../db")
const auth = require("../middleware/auth")

router.post("/apply",auth,async(req,res)=>{

const {date} = req.body

await db.query(
"INSERT INTO leave_requests(employee_id,leave_date,status) VALUES($1,$2,'Pending')",
[req.user.id,date]
)

res.json({message:"Leave requested"})

})

module.exports = router
