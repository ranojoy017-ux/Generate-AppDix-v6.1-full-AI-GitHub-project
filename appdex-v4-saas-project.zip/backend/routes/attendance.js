
const router = require("express").Router()
const db = require("../db")
const auth = require("../middleware/auth")

router.post("/checkin",auth,async(req,res)=>{

await db.query(
"INSERT INTO attendance(employee_id,check_in) VALUES($1,NOW())",
[req.user.id]
)

res.json({message:"Checked in"})

})

router.post("/checkout",auth,async(req,res)=>{

await db.query(
"UPDATE attendance SET check_out=NOW() WHERE employee_id=$1 AND check_out IS NULL",
[req.user.id]
)

res.json({message:"Checked out"})

})

module.exports = router
