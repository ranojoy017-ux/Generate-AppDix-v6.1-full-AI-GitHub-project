
const {Pool} = require("pg")

const pool = new Pool({
 user:"appdex",
 password:"appdex",
 host:"localhost",
 database:"appdex",
 port:5432
})

module.exports = pool
