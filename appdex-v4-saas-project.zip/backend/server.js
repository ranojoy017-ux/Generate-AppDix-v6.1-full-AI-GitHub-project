
const express = require("express")
const cors = require("cors")

const auth = require("./routes/auth")
const attendance = require("./routes/attendance")
const leave = require("./routes/leave")
const admin = require("./routes/admin")

const app = express()

app.use(cors())
app.use(express.json())

app.use("/api/auth",auth)
app.use("/api/attendance",attendance)
app.use("/api/leave",leave)
app.use("/api/admin",admin)

app.get("/",(req,res)=>{
 res.send("AppDix v4 API running")
})

app.listen(5000,()=>{
 console.log("Server started on port 5000")
})
