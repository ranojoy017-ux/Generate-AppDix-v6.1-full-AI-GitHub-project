
import {useState} from "react"
import api from "../api"

export default function Login(){

const [id,setId]=useState("")
const [pass,setPass]=useState("")

async function login(){

try{

let res = await api.post("/auth/login",{
employee_id:id,
password:pass
})

localStorage.setItem("token",res.data.token)

alert("Login success")

}catch(e){

alert("Login failed")

}

}

return(
<div>
<h2>AppDix Login</h2>
<input placeholder="Employee ID" onChange={e=>setId(e.target.value)}/>
<input type="password" placeholder="Password" onChange={e=>setPass(e.target.value)}/>
<button onClick={login}>Login</button>
</div>
)

}
