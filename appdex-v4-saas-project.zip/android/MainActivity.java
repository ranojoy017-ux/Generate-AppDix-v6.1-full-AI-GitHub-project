
package com.appdex;

import android.os.Bundle;
import android.webkit.WebView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

protected void onCreate(Bundle savedInstanceState){

super.onCreate(savedInstanceState);

WebView webView = new WebView(this);

setContentView(webView);

webView.getSettings().setJavaScriptEnabled(true);

webView.loadUrl("https://appdex.yourdomain.com");

}

}
